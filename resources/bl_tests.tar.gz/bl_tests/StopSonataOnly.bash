#!/bin/bash
/usr/bin/dolphin/WatchDogServer --stop
