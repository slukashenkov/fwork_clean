#!/bin/bash
/usr/bin/dolphin/WatchDogServer --start --conf=/usr/bin/dolphin/bl_tests/sonata_confs/main_sonata.xml >/dev/null
