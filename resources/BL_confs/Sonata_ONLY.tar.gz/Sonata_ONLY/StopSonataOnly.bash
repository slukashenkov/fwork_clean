#!/bin/bash
#./WatchDogServer --start --conf=./sonata_confs/main_sonata.xml
./WatchDogServer --stop
