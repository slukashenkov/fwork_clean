#/bin/bash

echo ${1}
param=${1}
echo ${param}

export param  
./test_this.bash
